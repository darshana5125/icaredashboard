<?php session_start();?>
<?php include($_SERVER['DOCUMENT_ROOT'].'/icaredashboard/ums/inc/connection.php'); ?>
<?php

// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: index.php');
	}
echo'<html><head>
<link rel="stylesheet" type="text/css" href="table_style.css"/> 
 <script src="\icaredashboard/libraries/jquery/jquery-1.9.1.js" ></script>
  <script src="\icaredashboard/libraries/jquery/ui/1.10.3/jquery-ui.js"></script>';
 



echo '<link rel="stylesheet" href="ums/css/main.css">';

 

 echo '<head></head>';
?>

<header>
		<div class="appname">iCare Dashboard</div>
		<div class="loggedin">Welcome <?php echo ucfirst($_SESSION['first_name']); ?>! <a href="ums/logout.php">Log Out</a></div>
</header>

<?php 
 echo'<body>';
 
 function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
	}
 
		 if(isset($_POST['ok']) ){
			 $date1=test_input($_POST['datepicker1']);
			 $date2=test_input($_POST['datepicker2']);
	
	 echo'<a href="https://192.168.47.25/icaredashboard/breached_list.php">Back</a>';	echo'<br><br>';	 
	 
		 
			 
	print "Breached issue list from " ; print $date1; print '  to  '; print $date2; echo'<br><br>';
			 
			 
			
			echo '<link rel="stylesheet" type="text/css" href="table_style.css"/> 
<div id="box"><table id="tablestyle"><th>Number</th><th>CustomerID</th><th>CSR#</th><th>Title</th><th>Created</th>
<th>Breached time</th>';


$query="select distinct t.customer_id as cx_id,t.tn as tn,t.title as title,t.create_time as create_time ,s.breached_time as breached_time from 
ticket t join sla_table s on
t.tn=s.tn
where sla_state='3' and breached_time between '$date1' and '$date2'
order by breached_time desc";


$query_run=mysqli_query($connection,$query);
$count=1;

while($result2=mysqli_fetch_assoc($query_run)) 
{
	
	echo '<tr><td class="no">'.$count.'</td>
	<td class="cx">'.$result2['cx_id'].'</td>'	;
	echo'<td class="csr">'.$result2['tn'].'</td>
	<td class="subject">'.$result2['title'].'</td>
	<td class="time">'.$result2['create_time'].'</td>
	<td class="owner"> '.$result2['breached_time'].'</td>

	
	</tr>';  
			 
			 
		$count++;
		 
		
			 
			 
		 }
	
}
	
	
echo' </html>';
 
 //mysqli_close($link);
 
 ?>
